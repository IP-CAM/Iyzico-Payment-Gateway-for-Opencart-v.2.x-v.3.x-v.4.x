<?php
// Text
$_['iyzico_img_title'] = '<img style="width: 25%" src="admin/view/image/payment/iyzico_cards.png" alt="iyzico"/>';
$_['payment_failed'] = 'Payment Failed';
$_['text_title'] = 'iyzico';
$_['payment_field_desc'] = 'Payment ID: ';
$_['installement_field_desc'] = ' Installment Commission';
$_['iyzico_onepage_desc'] = 'The payment form will be active when you fill in your information and confirm the complete order button.';
$_['iyzico_checkout_form_title'] = 'Payment Form';
$_['iyzico_checkout_form_desc'] = 'This payment form will be used to complete your order.';