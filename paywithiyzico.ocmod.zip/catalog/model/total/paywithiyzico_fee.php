<?php

namespace Opencart\Catalog\Model\Extension\iyzico\Total;
class paywithiyzico extends \Opencart\System\Engine\Model{

    public function confirm($order_info, $order_total)
    {

    }

}
